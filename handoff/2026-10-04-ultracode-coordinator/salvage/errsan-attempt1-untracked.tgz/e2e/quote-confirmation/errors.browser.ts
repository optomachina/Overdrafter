import { test as base, expect, type Page } from "@playwright/test";
import { FINGERPRINT } from "./data";
import { QuoteBrowserBackend } from "./network";

// Dedicated config only (*.browser.ts), with no skips. Failing RPC bodies carry synthetic
// secrets and stack frames; customer-visible text must stay bounded and offer a next action.
const JWT_SHAPED = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJzeW50aGV0aWMtZml4dHVyZSJ9.c3ludGhldGljLXNpZ25hdHVyZS1vbmx5";
const STACK_FRAME = "at fn (https://x.invalid/a.js:1:2)";
const SENTINELS = [JWT_SHAPED, "service_role", "storageState", STACK_FRAME];
const leakingBody = (code: string) => ({
  code,
  message: `Synthetic ${code} failure for service_role with ${JWT_SHAPED}`,
  details: `storageState {"cookies":[{"name":"sb-synthetic-auth-token","value":"${JWT_SHAPED}"}]}`,
  hint: `Error: synthetic failure\n    ${STACK_FRAME}`,
});

const test = base.extend<{ backend: QuoteBrowserBackend }>({
  backend: async ({ context }, provide) => { const backend = new QuoteBrowserBackend(); await backend.install(context); await provide(backend); },
  // Containment is installed before page creation, including popups.
  page: async ({ context, backend }, provide) => { void backend; const page = await context.newPage(); await provide(page); await page.close(); },
});

const dialog = (page: Page) => page.getByRole("dialog", { name: "Confirm Xometry beta quote request" });
const control = (page: Page, name: string) => dialog(page).getByRole("button", { name, exact: true }).first();
const accessReads = (backend: QuoteBrowserBackend) => backend.calls.filter(call => call.name === "api_get_quote_access").length;

async function openConfirmation(page: Page) {
  await page.goto("/e2e/quote-confirmation/index.html");
  await page.getByRole("button", { name: "Request quote", exact: true }).click();
  await expect(dialog(page)).toBeVisible();
}

/** Page text (rendered and hidden), every toast and every dialog must omit all sentinels. */
async function expectNoSentinel(page: Page) {
  const surfaces = [
    await page.locator("body").innerText(),
    (await page.locator("body").textContent()) ?? "",
    ...await page.locator("[data-sonner-toast]").allInnerTexts(),
    ...await page.getByRole("dialog").allInnerTexts(),
  ];
  for (const surface of surfaces) {
    for (const sentinel of SENTINELS) expect(surface, `customer-visible text exposes ${sentinel}`).not.toContain(sentinel);
  }
}

test.afterEach(async ({ backend }, testInfo) => {
  await testInfo.attach("synthetic-error-rpc-audit", { contentType: "application/json", body: JSON.stringify({
    calls: backend.calls, syntheticLogicalCreates: backend.committed.size, blockedRequests: backend.forbidden, pageErrors: backend.pageErrors,
  }, null, 2) });
  expect(backend.forbidden, "Unexpected calls were blocked before send").toEqual([]);
  expect(backend.pageErrors).toEqual([]);
});

test("scope lookup 400 shows bounded copy with retry and close, never the server body", async ({ page, backend }) => {
  backend.failureBody = leakingBody("XX000");
  backend.scopeMode = "error";
  await openConfirmation(page);
  await control(page, "Inches").click();
  const alert = dialog(page).getByRole("alert");
  await expect(alert).toContainText("This package is not ready for controlled Xometry beta dispatch.");
  await expectNoSentinel(page);
  await expect(alert).toContainText("The Xometry confirmation scope could not be loaded.");
  await expect(control(page, "Retry scope check")).toBeEnabled();
  await expect(control(page, "Close")).toBeEnabled();
  await expect(control(page, "Confirm & queue Xometry quote")).toBeDisabled();
  backend.failureBody = null;
  backend.scopeMode = "ready";
  await control(page, "Retry scope check").click();
  await expect(dialog(page).getByText(FINGERPRINT, { exact: true })).toBeVisible();
  expect(backend.dispatches).toHaveLength(0);
});

test("dispatch 500 keeps the unknown outcome bounded and retries the same reference", async ({ page, backend }) => {
  backend.failureBody = leakingBody("XX000");
  await openConfirmation(page);
  await control(page, "Inches").click();
  await expect(dialog(page).getByText(FINGERPRINT, { exact: true })).toBeVisible();
  await expect(dialog(page).getByRole("checkbox")).toHaveCount(3);
  for (const box of await dialog(page).getByRole("checkbox").all()) await box.check();
  backend.nextReply = "failed";
  await control(page, "Confirm & queue Xometry quote").click();
  const alert = dialog(page).getByRole("alert");
  await expect(page.locator("[data-sonner-toast]").filter({ hasText: "The request status could not be confirmed." })).toBeVisible();
  await expectNoSentinel(page);
  await expect(alert).toContainText("We could not confirm whether the request was queued.");
  await expect(alert).toContainText("Diagnostic: postgrest_failure.");
  await expect(control(page, "Confirm & queue Xometry quote")).toBeEnabled();
  await expect(control(page, "Close")).toBeEnabled();
  expect(backend.dispatches).toHaveLength(1);
  expect(backend.committed.size).toBe(0);
  backend.failureBody = null;
  await control(page, "Confirm & queue Xometry quote").click();
  await expect(dialog(page).getByText("Xometry quote request queued", { exact: true })).toBeVisible();
  expect(backend.dispatches).toHaveLength(2);
  expect(backend.dispatches[1].input).toEqual(backend.dispatches[0].input);
  expect(backend.committed.size).toBe(1);
});

test("quote-access errors fail closed with bounded copy and a retry, never the server body", async ({ page, backend }) => {
  backend.failureBody = leakingBody("PGRST000");
  backend.accessMode = "error";
  await page.goto("/e2e/quote-confirmation/index.html");
  await expect.poll(() => accessReads(backend)).toBe(1);
  await expect(page.getByText(/Automatic quote collection is not enabled for this organization/)).toBeVisible();
  await expect(page.getByRole("button", { name: "Request quote", exact: true })).toHaveCount(0);
  await expectNoSentinel(page);

  // A failed access refresh inside the open confirmation keeps Retry and Close available.
  backend.accessMode = "eligible";
  backend.scopeMode = "error";
  await openConfirmation(page);
  await control(page, "Inches").click();
  await expect(control(page, "Retry scope check")).toBeEnabled();
  backend.accessMode = "error";
  backend.scopeMode = "ready";
  const readsBeforeRetry = accessReads(backend);
  await control(page, "Retry scope check").click();
  await expect.poll(() => accessReads(backend)).toBeGreaterThan(readsBeforeRetry);
  await expect(dialog(page).getByRole("alert")).toContainText("Automatic Xometry beta dispatch is not enabled for this organization.");
  await expectNoSentinel(page);
  await expect(control(page, "Retry scope check")).toBeEnabled();
  await expect(control(page, "Close")).toBeEnabled();
  await expect(control(page, "Confirm & queue Xometry quote")).toBeDisabled();
  backend.failureBody = null;
  backend.accessMode = "eligible";
  await control(page, "Retry scope check").click();
  await expect(dialog(page).getByText(FINGERPRINT, { exact: true })).toBeVisible();
  expect(backend.dispatches).toHaveLength(0);
});
