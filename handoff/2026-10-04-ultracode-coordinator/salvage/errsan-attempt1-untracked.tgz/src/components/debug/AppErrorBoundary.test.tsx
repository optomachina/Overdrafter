import "@testing-library/jest-dom/vitest";
import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { AppErrorBoundary } from "./AppErrorBoundary";

const mockCaptureDiagnosticError = vi.hoisted(() => vi.fn());

vi.mock("@/lib/diagnostics", () => ({
  captureDiagnosticError: mockCaptureDiagnosticError,
  copyTextToClipboard: vi.fn(),
  createDiagnosticClipboardText: vi.fn(),
}));

vi.mock("sonner", () => ({ toast: { success: vi.fn(), error: vi.fn() } }));

// Synthetic, non-credential sentinel shaped like a leaked token plus a privileged role name.
const RAW_MESSAGE =
  "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJzeW50aGV0aWMtZml4dHVyZSJ9.c3ludGhldGljLXNpZ25hdHVyZS1vbmx5 service_role";

function ThrowingChild(): never {
  throw new Error(RAW_MESSAGE);
}

function renderRenderFailure() {
  render(
    <AppErrorBoundary>
      <ThrowingChild />
    </AppErrorBoundary>,
  );
}

function expectRecoveryChrome() {
  expect(screen.getByRole("heading", { name: "The app hit a render failure." })).toBeInTheDocument();
  expect(screen.getByText("Reference: diagnostic-reference-1")).toBeInTheDocument();
  expect(screen.getByRole("button", { name: "Reload app" })).toBeEnabled();
}

describe("AppErrorBoundary", () => {
  beforeEach(() => {
    mockCaptureDiagnosticError.mockReturnValue("diagnostic-reference-1");
    // React reports the caught render error to the console; the assertions below cover it.
    vi.spyOn(console, "error").mockImplementation(() => undefined);
  });

  afterEach(() => {
    cleanup();
    vi.unstubAllEnvs();
  });

  it("shows only the generic message outside development while diagnostics keep the raw error", () => {
    vi.stubEnv("DEV", false);

    renderRenderFailure();

    expectRecoveryChrome();
    expect(screen.getByText("Something went wrong.")).toBeInTheDocument();
    expect(document.body.textContent).not.toContain("service_role");
    expect(document.body.textContent).not.toContain("eyJhbGciOiJIUzI1NiJ9");
    expect(mockCaptureDiagnosticError).toHaveBeenCalledWith(
      expect.objectContaining({ message: RAW_MESSAGE }),
      expect.objectContaining({ source: "react.error-boundary" }),
    );
  });

  it("shows the raw message in development", () => {
    vi.stubEnv("DEV", true);

    renderRenderFailure();

    expectRecoveryChrome();
    expect(screen.getByText(RAW_MESSAGE)).toBeInTheDocument();
    expect(screen.queryByText("Something went wrong.")).not.toBeInTheDocument();
  });
});
