import "dotenv/config";
import path from "node:path";
import type { PostgrestResponse, SupabaseClient } from "@supabase/supabase-js";
import { buildAdapterRegistry } from "./adapters/index.js";
import { autoApproveJobRequirements } from "./autoApprove.js";
import { XOMETRY_AUTOMATION_VERSION } from "./adapters/xometry.js";
import { loadConfig } from "./config.js";
import { runHybridExtraction } from "./extraction/hybridExtraction.js";
import { buildGeometryProjectionArtifact } from "./extraction/geometryProjection.js";
import {
  buildStoredExtractionPayload,
  currentExtractorVersion,
  summarizeExtractionOutcome,
} from "./extraction/sharedResult.js";
import {
  ExtractionModelCatalogManager,
  previewStoredPartExtraction,
} from "./extraction/debugLab.js";
import {
  extractPdfText,
  renderPdfFirstPagePreview,
  renderPdfPreviewAssets,
} from "./extraction/pdfDrawing.js";
import {
  cleanupPaths,
  createRunDir,
  stageStorageObject,
  uploadArtifact,
} from "./files.js";
import { buildQuoteLaneScopeSnapshot } from "./quoteScope.js";
import {
  claimNextTask,
  createServiceClient,
  markTaskCancelled,
  markTaskCompleted,
  markTaskFailed,
  markTaskQueuedForRetry,
  reapStaleTasks,
} from "./queue.js";
import {
  createWorkerRuntimeState,
  getXometrySessionAgeDays,
  recordRuntimeEvent,
  startHealthServer,
  type WorkerRuntimeState,
} from "./httpServer.js";
import {
  buildWorkerTaskFailureEvidence,
  summarizeWorkerError,
  summarizeWorkerErrorName,
} from "./errorSummary.js";
import { suggestLocatorUpdate } from "./repair/suggestLocatorUpdate.js";
import { prepareRuntimeSecrets, validateWorkerReadiness } from "./runtimeSecrets.js";
import { fetchPartContext } from "./partContext.js";
import {
  ApprovedRequirementRecord,
  DrawingExtractionPayload,
  JobFileRecord,
  PartRecord,
  QueueTaskRecord,
  VendorArtifact,
  VendorAutomationError,
  VendorName,
  WorkerConfig,
} from "./types.js";
import { buildExtractionCompletionPayload } from "./extractionObservability.js";
import { createSpendGuard, SpendCapExceededError } from "./spendGuard.js";
import {
  failureCodeForError,
  isRetryableVendorTaskError,
  nextRetryAt,
  retryCountForAttempts,
} from "./vendorTaskRetry.js";
import { aggregateQuoteRunStatus } from "./quoteRunStatus.js";
import { shouldWarnSimulateModeInProduction } from "./runtimeEnvironment.js";
import { computeAndStoreRoutingScores } from "./scoringIntegration.js";
import { buildVendorQuoteOfferPayloads } from "./vendorQuoteOffer.js";
import { finalizeVendorQuoteResult } from "./vendorQuoteOfferPersistence.js";
import {
  enqueueCadPreviewGenerationTask,
  ensurePersistentCadPreview,
} from "./cadPreviewPersistence.js";
import { isRetryableCadPreviewError } from "./cadPreview.js";
import { isDirectExtractionModelId } from "./extraction/modelRegistry.js";
import {
  quoteWithDispatchPreflight,
  XometryDispatchAuthorizationError,
} from "./xometryDispatchPreflight.js";

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Booked per model attempt before the call, then replaced by the observed cost.
 *
 * Deliberately generous relative to a typical extraction: the reservation has to
 * be made before token counts are known, and over-booking briefly is the safe
 * direction. Under-booking would let a burst of concurrent calls collectively
 * overshoot the ceiling.
 */
const MODEL_CALL_SPEND_ESTIMATE_USD = 0.25;

/** Booked per vendor automation lane, covering its browser container time. */
const VENDOR_RUN_SPEND_ESTIMATE_USD = 0.05;

class CanonicalArtifactsPendingError extends Error {
  constructor(sourcePartId: string) {
    super(`Canonical part artifacts are still being prepared by source part ${sourcePartId}.`);
    this.name = "CanonicalArtifactsPendingError";
  }
}

function buildTaskContext(task: QueueTaskRecord) {
  return {
    taskId: task.id,
    taskType: task.task_type,
    attempts: task.attempts,
    organizationId: task.organization_id,
    jobId: task.job_id,
    partId: task.part_id,
    quoteRequestId:
      typeof task.payload.quoteRequestId === "string" ? task.payload.quoteRequestId : null,
    serviceRequestLineItemId:
      typeof task.payload.serviceRequestLineItemId === "string" ? task.payload.serviceRequestLineItemId : null,
    quoteRunId: task.quote_run_id,
    packageId: task.package_id,
    vendor: typeof task.payload.vendor === "string" ? task.payload.vendor : null,
    vendorQuoteResultId:
      typeof task.payload.vendorQuoteResultId === "string" ? task.payload.vendorQuoteResultId : null,
    requestedQuantity:
      typeof task.payload.requestedQuantity === "number"
        ? task.payload.requestedQuantity
        : typeof task.payload.requestedQuantity === "string"
          ? Number.parseInt(task.payload.requestedQuantity, 10)
          : null,
  };
}

function logWorkerEvent(
  runtimeState: WorkerRuntimeState,
  input: {
    level: "info" | "warn" | "error";
    source: string;
    message: string;
    context?: Record<string, unknown>;
    error?: unknown;
  },
) {
  const event = recordRuntimeEvent(runtimeState, input);
  const payload = {
    service: "overdrafter-cad-worker",
    workerStatus: runtimeState.status,
    timestamp: event.timestamp,
    level: event.level,
    source: event.source,
    message: event.message,
    context: event.context,
    error: event.error,
  };
  const serialized = JSON.stringify(payload);

  if (input.level === "error") {
    console.error(serialized);
    return;
  }

  if (input.level === "warn") {
    console.warn(serialized);
    return;
  }

  console.log(serialized);
}

function logPreviewRenderWarning(task: QueueTaskRecord, stage: "all_pages" | "first_page", error: unknown) {
  console.warn(
    JSON.stringify({
      service: "overdrafter-cad-worker",
      level: "warn",
      source: "worker.preview.render",
      message: `Failed to render ${stage === "all_pages" ? "all page previews" : "the first-page preview"} for ${task.task_type} ${task.id}: ${summarizeWorkerError(error)}`,
      context: {
        ...buildTaskContext(task),
        stage,
      },
      error: {
        name: summarizeWorkerErrorName(error),
        message: summarizeWorkerError(error),
      },
    }),
  );
}

function logCadPreviewWarning(task: QueueTaskRecord, error: unknown) {
  console.warn(
    JSON.stringify({
      service: "overdrafter-cad-worker",
      level: "warn",
      source: "worker.cad-preview.render",
      message: `Failed to generate the persistent CAD preview for ${task.task_type} ${task.id}: ${summarizeWorkerError(error)}`,
      context: buildTaskContext(task),
      error: {
        name: summarizeWorkerErrorName(error),
        message: summarizeWorkerError(error),
      },
    }),
  );
}


async function logWorkerAuditEvent(
  supabase: SupabaseClient,
  input: {
    organizationId: string;
    jobId: string;
    packageId?: string | null;
    eventType: string;
    payload?: Record<string, unknown>;
  },
) {
  const { error } = await supabase.from("audit_events").insert({
    organization_id: input.organizationId,
    actor_user_id: null,
    job_id: input.jobId,
    package_id: input.packageId ?? null,
    event_type: input.eventType,
    payload: input.payload ?? {},
  });

  if (error) {
    throw error;
  }
}

function buildFailureRawPayload(
  vendor: VendorName,
  retryCount: number,
  failureCode: string,
  payload: Record<string, unknown>,
  artifactStoragePaths: string[],
) {
  if (vendor !== "xometry") {
    return {
      failureCode,
      retryCount,
      requestedQuantity:
        typeof payload.requestedQuantity === "number" ? payload.requestedQuantity : null,
      ...payload,
      artifactStoragePaths,
    };
  }

  return {
    automationVersion: XOMETRY_AUTOMATION_VERSION,
    detectedFlow:
      typeof payload.detectedFlow === "string" ? payload.detectedFlow : "quote_home",
    uploadSelector:
      typeof payload.uploadSelector === "string" ? payload.uploadSelector : null,
    drawingUploadMode:
      typeof payload.drawingUploadMode === "string" ? payload.drawingUploadMode : null,
    selectedMaterial:
      typeof payload.selectedMaterial === "string" ? payload.selectedMaterial : null,
    selectedFinish:
      typeof payload.selectedFinish === "string" ? payload.selectedFinish : null,
    priceSource:
      typeof payload.priceSource === "string" ? payload.priceSource : "none",
    leadTimeSource:
      typeof payload.leadTimeSource === "string" ? payload.leadTimeSource : "none",
    bodyExcerpt: typeof payload.bodyExcerpt === "string" ? payload.bodyExcerpt : "",
    artifactStoragePaths,
    requestedQuantity:
      typeof payload.requestedQuantity === "number" ? payload.requestedQuantity : null,
    retryCount,
    failureCode,
    url: typeof payload.url === "string" ? payload.url : null,
    ...payload,
  };
}

async function refreshRuntimeReadiness(
  config: WorkerConfig,
  runtimeState: WorkerRuntimeState,
  logIssueChange: (issues: string[]) => void,
) {
  const issues = await validateWorkerReadiness(config);
  const previousSignature = runtimeState.readinessIssues.join("\n");
  const nextSignature = issues.join("\n");

  runtimeState.readinessIssues = issues;

  if (issues.length > 0) {
    runtimeState.lastError = issues.join(" ");
  } else if (previousSignature.length > 0) {
    runtimeState.lastError = null;
  }

  if (previousSignature !== nextSignature) {
    logIssueChange(issues);
  }

  return issues.length === 0;
}


async function enqueueRepairCandidate(
  supabase: SupabaseClient,
  task: QueueTaskRecord,
  error: VendorAutomationError,
) {
  if (error.code !== "selector_failure" || !task.job_id || !task.part_id || !task.quote_run_id) {
    return;
  }

  const { error: insertError } = await supabase.from("work_queue").insert({
    organization_id: task.organization_id,
    job_id: task.job_id,
    part_id: task.part_id,
    quote_run_id: task.quote_run_id,
    task_type: "repair_adapter_candidate",
    status: "queued",
    payload: {
      vendor: task.payload.vendor,
      failedSelector: error.payload.failedSelector ?? null,
      attemptedSelectors: error.payload.attemptedSelectors ?? [],
      errorMessage: error.message,
      nearbyAttributes: error.payload.nearbyAttributes ?? [],
      failureCode: error.code,
      url: error.payload.url ?? null,
    },
  });

  if (insertError) {
    throw insertError;
  }
}

async function persistVendorArtifacts(
  supabase: SupabaseClient,
  config: WorkerConfig,
  input: {
    vendorQuoteResultId: string;
    organizationId: string;
    quoteRunId: string;
    partId: string;
    vendor: VendorName;
    artifacts: VendorArtifact[];
  },
) {
  const storagePaths: string[] = [];

  for (const artifact of input.artifacts) {
    storagePaths.push(
      await uploadArtifact(supabase, config, {
        vendorQuoteResultId: input.vendorQuoteResultId,
        organizationId: input.organizationId,
        quoteRunId: input.quoteRunId,
        partId: input.partId,
        vendor: input.vendor,
        artifact,
      }),
    );
  }

  return storagePaths;
}

async function syncJobStatusAfterVendorUpdate(
  supabase: SupabaseClient,
  jobId: string,
  quoteRunId: string,
) {
  const [
    { data: results, error: resultsError },
    { data: job, error: jobError },
    { data: quoteRun, error: quoteRunError },
  ] = await Promise.all([
    supabase.from("vendor_quote_results").select("status").eq("quote_run_id", quoteRunId),
    supabase.from("jobs").select("organization_id, status").eq("id", jobId).single(),
    supabase.from("quote_runs").select("status").eq("id", quoteRunId).single(),
  ]);

  if (resultsError || !results) {
    throw resultsError ?? new Error("Unable to refresh job status.");
  }

  if (jobError || !job) {
    throw jobError ?? new Error("Unable to load job status.");
  }

  if (quoteRunError || !quoteRun) {
    throw quoteRunError ?? new Error("Unable to load quote run status.");
  }

  const statuses = results.map((row) => row.status);
  const {
    nextQuoteRunStatus,
    nextJobStatus,
    successfulVendorQuotes,
    manualReviewVendorQuotes,
    failedVendorQuotes,
  } = aggregateQuoteRunStatus(statuses);

  await supabase
    .from("quote_runs")
    .update({
      status: nextQuoteRunStatus,
    })
    .eq("id", quoteRunId);

  await supabase
    .from("jobs")
    .update({
      status: nextJobStatus,
    })
    .eq("id", jobId);

  if (quoteRun.status === nextQuoteRunStatus && job.status === nextJobStatus) {
    return;
  }

  const basePayload = {
    quoteRunId,
    successfulVendorQuotes,
    manualReviewVendorQuotes,
    failedVendorQuotes,
  };

  if (nextQuoteRunStatus === "failed") {
    await logWorkerAuditEvent(supabase, {
      organizationId: job.organization_id,
      jobId,
      eventType: "worker.quote_run_failed",
      payload: basePayload,
    });
    return;
  }

  if (nextJobStatus === "awaiting_vendor_manual_review") {
    await logWorkerAuditEvent(supabase, {
      organizationId: job.organization_id,
      jobId,
      eventType: "worker.quote_run_attention_needed",
      payload: basePayload,
    });
    return;
  }

  if (nextJobStatus === "internal_review") {
    await logWorkerAuditEvent(supabase, {
      organizationId: job.organization_id,
      jobId,
      eventType: "worker.quote_run_completed",
      payload: basePayload,
    });
  }
}

async function persistDrawingPreviewAssets(
  supabase: SupabaseClient,
  config: WorkerConfig,
  input: {
    organizationId: string;
    partId: string;
    jobId: string;
    previewAssets: Awaited<ReturnType<typeof renderPdfPreviewAssets>>;
  },
) {
  if (input.previewAssets.length === 0) {
    await supabase.from("drawing_preview_assets").delete().eq("part_id", input.partId);
    return;
  }

  const rows = [] as Array<{
    part_id: string;
    organization_id: string;
    page_number: number;
    kind: string;
    storage_bucket: string;
    storage_path: string;
    width: number | null;
    height: number | null;
  }>;

  for (const asset of input.previewAssets) {
    const fileBuffer = await pathToBuffer(asset.localPath);
    const storagePath = `${input.organizationId}/drawing-previews/${input.jobId}/${input.partId}/${asset.kind}-${asset.pageNumber}.png`;
    const { error: uploadError } = await supabase.storage.from(config.artifactBucket).upload(storagePath, fileBuffer, {
      contentType: asset.contentType,
      upsert: true,
    });

    if (uploadError) {
      throw uploadError;
    }

    rows.push({
      part_id: input.partId,
      organization_id: input.organizationId,
      page_number: asset.pageNumber,
      kind: asset.kind,
      storage_bucket: config.artifactBucket,
      storage_path: storagePath,
      width: asset.width,
      height: asset.height,
    });
  }

  await supabase.from("drawing_preview_assets").delete().eq("part_id", input.partId);

  const { error: insertError } = await supabase.from("drawing_preview_assets").insert(rows);

  if (insertError) {
    throw insertError;
  }
}

async function pathToBuffer(filePath: string) {
  const { readFile } = await import("node:fs/promises");
  return readFile(filePath);
}

function resolveDebugExtractionModel(config: WorkerConfig, requestedModel: unknown) {
  const requested =
    typeof requestedModel === "string" && requestedModel.trim().length > 0
      ? requestedModel.trim()
      : config.drawingExtractionModel;

  if (!isDirectExtractionModelId(requested)) {
    throw new Error("Debug extraction requires a direct OpenAI or Anthropic model.");
  }

  if (!config.drawingExtractionDebugAllowedModels.includes(requested)) {
    throw new Error(
      `Debug extraction model "${requested}" is not allowlisted. Allowed models: ${config.drawingExtractionDebugAllowedModels.join(", ")}`,
    );
  }

  return requested;
}

async function runDrawingExtractionForTask(
  supabase: SupabaseClient,
  task: QueueTaskRecord,
  config: WorkerConfig,
  requestedModel: string | null = null,
) {
  if (!task.part_id || !task.job_id) {
    throw new Error(`${task.task_type} task is missing job_id or part_id.`);
  }

  const context = await fetchPartContext(supabase, task.part_id);
  const runDir = await createRunDir(config, ["extract", task.id]);
  const stagedDrawingFile = await stageStorageObject(supabase, context.drawingFile, runDir);

  try {
    const pdfText = stagedDrawingFile ? await extractPdfText(stagedDrawingFile.localPath) : null;
    let previewAssets = [] as Awaited<ReturnType<typeof renderPdfPreviewAssets>>;

    if (stagedDrawingFile && pdfText) {
      try {
        previewAssets = await renderPdfPreviewAssets(stagedDrawingFile.localPath, runDir, pdfText.pageCount);
      } catch (error) {
        logPreviewRenderWarning(task, "all_pages", error);
        previewAssets = [];
      }
    }

    let firstPagePreviewPath =
      previewAssets.find((asset) => asset.kind === "page" && asset.pageNumber === 1)?.localPath ?? null;

    if (stagedDrawingFile && !firstPagePreviewPath) {
      let fallbackPreviewAsset = null;

      try {
        fallbackPreviewAsset = await renderPdfFirstPagePreview(
          stagedDrawingFile.localPath,
          path.join(runDir, "drawing-page-1.png"),
        );
      } catch (error) {
        logPreviewRenderWarning(task, "first_page", error);
      }

      if (fallbackPreviewAsset) {
        previewAssets = [
          ...previewAssets.filter(
            (asset) => !(asset.kind === "page" && asset.pageNumber === fallbackPreviewAsset.pageNumber),
          ),
          fallbackPreviewAsset,
        ];
        firstPagePreviewPath = fallbackPreviewAsset.localPath;
      }
    }

    const effectiveModel = requestedModel
      ? resolveDebugExtractionModel(config, requestedModel)
      : config.drawingExtractionModel;
    const extractionConfig =
      effectiveModel === config.drawingExtractionModel
        ? config
        : {
            ...config,
            drawingExtractionModel: effectiveModel,
          };
    const extraction = await runHybridExtraction({
      part: context.part,
      cadFile: context.cadFile,
      drawingFile: context.drawingFile,
      pdfText,
      drawingPath: stagedDrawingFile?.localPath ?? null,
      previewPagePath: firstPagePreviewPath,
      runDir,
      config: extractionConfig,
      // Budget is enforced here rather than at request admission: a ceiling
      // checked when a user clicks something cannot stop a retry storm or a
      // stuck loop, which is the shape a runaway actually takes.
      spend: {
        guard: createSpendGuard(supabase, task.organization_id),
        estimatedUsd: MODEL_CALL_SPEND_ESTIMATE_USD,
        context: { jobId: task.job_id, partId: task.part_id, taskId: task.id },
      },
    });
    const extractionOutcome = summarizeExtractionOutcome(extraction);
    const extractorVersion = currentExtractorVersion(Boolean(stagedDrawingFile));
    const geometryProjection = buildGeometryProjectionArtifact({
      extraction,
      requirement: context.requirement,
      extractorVersion,
    });

    if (process.env.EXTRACTION_DEBUG === "true" && extraction.debugCandidates) {
      console.log(
        JSON.stringify({
          service: "overdrafter-cad-worker",
          source: task.task_type,
          message: "drawing extraction candidate ranking",
          partId: context.part.id,
          reviewFields: extraction.reviewFields,
          candidates: extraction.debugCandidates,
        }),
      );
    }

    return {
      context,
      runDir,
      stagedDrawingFile,
      pdfText,
      previewAssets,
      firstPagePreviewPath,
      extraction,
      extractionOutcome,
      extractorVersion,
      geometryProjection,
      effectiveModel,
    };
  } catch (error) {
    await cleanupPaths([runDir]);
    throw error;
  }
}

async function handleExtractTask(supabase: SupabaseClient, task: QueueTaskRecord, config: WorkerConfig) {
  let runDir: string | null = null;
  let organizationIdForError: string | null = null;
  let partIdForError: string | null = task.part_id;
  try {
    const identityContext = await fetchPartContext(supabase, task.part_id!);
    const identityStageDir = await createRunDir(config, ["identity", task.id]);
    runDir = identityStageDir;
    await stageStorageObject(supabase, identityContext.cadFile, identityStageDir);
    await stageStorageObject(supabase, identityContext.drawingFile, identityStageDir);

    const { data: trustedIntake, error: trustedIntakeError } = await supabase.rpc(
      "api_resolve_trusted_part_intake",
      { p_part_id: task.part_id },
    );
    if (trustedIntakeError) {
      throw trustedIntakeError;
    }

    const trustedResult = trustedIntake && typeof trustedIntake === "object"
      ? trustedIntake as {
          result?: unknown;
          partVersionId?: unknown;
          sourcePartId?: unknown;
        }
      : null;
    const sourcePartId = typeof trustedResult?.sourcePartId === "string"
      ? trustedResult.sourcePartId
      : null;
    const partVersionId = typeof trustedResult?.partVersionId === "string"
      ? trustedResult.partVersionId
      : null;

    if (trustedResult?.result === "existing_version" && sourcePartId && partVersionId) {
      const { data: reuseResult, error: reuseError } = await supabase.rpc(
        "api_reuse_trusted_part_version_artifacts",
        {
          p_target_part_id: task.part_id,
          p_source_part_id: sourcePartId,
          p_part_version_id: partVersionId,
        },
      );
      if (reuseError) {
        throw reuseError;
      }
      const artifactsReady = reuseResult && typeof reuseResult === "object"
        ? (reuseResult as { artifactsReady?: unknown }).artifactsReady === true
        : false;
      const extractTargetIndependently = reuseResult && typeof reuseResult === "object"
        ? (reuseResult as { extractTargetIndependently?: unknown }).extractTargetIndependently === true
        : false;
      if (!artifactsReady) {
        if (!extractTargetIndependently) {
          throw new CanonicalArtifactsPendingError(sourcePartId);
        }
      } else {
        const autoApprovedPartCount = await autoApproveJobRequirements(supabase, task.job_id!);
        await markTaskCompleted(supabase, task, {
          canonicalPartVersionId: partVersionId,
          reusedCanonicalPartVersion: true,
          sourcePartId,
          autoApprovedPartCount,
        });
        return;
      }
    }

    await cleanupPaths([identityStageDir]);
    runDir = null;
    const extractionRun = await runDrawingExtractionForTask(supabase, task, config);
    runDir = extractionRun.runDir;
    const { context, extraction, extractionOutcome, pdfText, previewAssets, extractorVersion, geometryProjection } =
      extractionRun;
    organizationIdForError = context.part.organization_id;
    partIdForError = context.part.id;

    const { error } = await supabase.from("drawing_extractions").upsert(
      {
        part_id: context.part.id,
        organization_id: context.part.organization_id,
        extractor_version: extractorVersion,
        extraction: buildStoredExtractionPayload(
          extraction,
          pdfText?.pageCount ?? 0,
          config.workerBuildVersion,
          geometryProjection,
        ),
        confidence: extraction.material.confidence,
        warnings: extraction.warnings,
        evidence: extraction.evidence,
        status: extraction.status,
      },
      {
        onConflict: "part_id",
      },
    );

    if (error) {
      throw error;
    }

    await persistDrawingPreviewAssets(supabase, config, {
      organizationId: context.part.organization_id,
      partId: context.part.id,
      jobId: task.job_id!,
      previewAssets,
    });
    let cadPreviewStatus: "current" | "generated" | "skipped" | "failed" = "skipped";
    try {
      const cadPreviewResult = await ensurePersistentCadPreview(supabase, config, {
        organizationId: context.part.organization_id,
        jobId: task.job_id!,
        partId: context.part.id,
        cadFile: context.cadFile,
        runDir: extractionRun.runDir,
      });
      cadPreviewStatus = cadPreviewResult.status;
    } catch (error) {
      cadPreviewStatus = "failed";
      logCadPreviewWarning(task, error);
      try {
        await enqueueCadPreviewGenerationTask(supabase, {
          organizationId: context.part.organization_id,
          jobId: task.job_id!,
          partId: context.part.id,
          cadFileId: context.cadFile?.id ?? null,
          source: "extract_part_retry",
        });
      } catch (enqueueError) {
        logCadPreviewWarning(task, enqueueError);
      }
    }
    const autoApprovedPartCount = await autoApproveJobRequirements(supabase, task.job_id!);
    const completedAt = new Date().toISOString();
    const completionPayload = buildExtractionCompletionPayload({
      extraction,
      extractionOutcome,
      extractorVersion,
      workerBuildVersion: config.workerBuildVersion,
      previewAssetCount: previewAssets.length,
      autoApprovedPartCount,
      completedAt,
    });
    await logWorkerAuditEvent(supabase, {
      organizationId: context.part.organization_id,
      jobId: task.job_id!,
      eventType: "worker.extraction_completed",
      payload: {
        partId: context.part.id,
        cadPreviewStatus,
        ...completionPayload,
      },
    });
    await markTaskCompleted(supabase, task, {
      cadPreviewStatus,
      ...completionPayload,
    });
  } catch (error) {
    if (organizationIdForError && task.job_id) {
      await logWorkerAuditEvent(supabase, {
        organizationId: organizationIdForError,
        jobId: task.job_id,
        eventType: "worker.extraction_failed",
        payload: {
          partId: partIdForError,
          failureCode: failureCodeForError(error),
          failureMessage: summarizeWorkerError(error),
        },
      });
    }
    throw error;
  } finally {
    await cleanupPaths(runDir ? [runDir] : []);
  }
}

async function handleGenerateCadPreviewTask(
  supabase: SupabaseClient,
  task: QueueTaskRecord,
  config: WorkerConfig,
) {
  if (!task.part_id || !task.job_id) {
    throw new Error("generate_cad_preview task is missing job_id or part_id.");
  }

  const runDir = await createRunDir(config, ["cad-preview", task.id]);

  try {
    const context = await fetchPartContext(supabase, task.part_id);
    const result = await ensurePersistentCadPreview(supabase, config, {
      organizationId: context.part.organization_id,
      jobId: task.job_id,
      partId: context.part.id,
      cadFile: context.cadFile,
      runDir,
    });

    await logWorkerAuditEvent(supabase, {
      organizationId: context.part.organization_id,
      jobId: task.job_id,
      eventType: "worker.cad_preview_completed",
      payload: {
        partId: context.part.id,
        cadFileId: context.cadFile?.id ?? null,
        status: result.status,
        triangleCount: result.triangleCount,
        featureEdgeCount: result.featureEdgeCount,
      },
    });
    await markTaskCompleted(supabase, task, {
      cadPreviewStatus: result.status,
      triangleCount: result.triangleCount,
      featureEdgeCount: result.featureEdgeCount,
    });
  } finally {
    await cleanupPaths([runDir]);
  }
}

async function handleDebugExtractTask(
  supabase: SupabaseClient,
  task: QueueTaskRecord,
  config: WorkerConfig,
) {
  const debugRunId =
    typeof task.payload.debugRunId === "string" && task.payload.debugRunId.length > 0
      ? task.payload.debugRunId
      : null;

  if (!debugRunId) {
    throw new Error("debug_extract_part task is missing debugRunId.");
  }

  const requestedModel =
    typeof task.payload.requestedModel === "string" && task.payload.requestedModel.trim().length > 0
      ? task.payload.requestedModel.trim()
      : null;

  await supabase
    .from("debug_extraction_runs")
    .update({
      status: "running",
      started_at: new Date().toISOString(),
      error: null,
    })
    .eq("id", debugRunId);

  let runDir: string | null = null;

  try {
    const extractionRun = await runDrawingExtractionForTask(
      supabase,
      task,
      config,
      requestedModel,
    );
    runDir = extractionRun.runDir;
    const {
      context,
      extraction,
      extractionOutcome,
      pdfText,
      previewAssets,
      effectiveModel,
      extractorVersion,
      geometryProjection,
    } =
      extractionRun;
    const result = {
      extraction: buildStoredExtractionPayload(
        extraction,
        pdfText?.pageCount ?? 0,
        config.workerBuildVersion,
        geometryProjection,
      ),
      status: extraction.status,
      warnings: extraction.warnings,
      evidence: extraction.evidence,
      summary: extractionOutcome,
      preview: {
        pageCount: pdfText?.pageCount ?? 0,
        previewAssetCount: previewAssets.length,
        hasPreviewImage: previewAssets.some((asset) => asset.kind === "page" && asset.pageNumber === 1),
      },
    };

    const { error: debugRunError } = await supabase
      .from("debug_extraction_runs")
      .update({
        status: "completed",
        effective_model: effectiveModel,
        worker_build_version: config.workerBuildVersion,
        extractor_version: extractorVersion,
        model_fallback_used: extraction.modelFallbackUsed ?? false,
        model_prompt_version: extraction.modelPromptVersion ?? null,
        result,
        error: null,
        completed_at: new Date().toISOString(),
      })
      .eq("id", debugRunId);

    if (debugRunError) {
      throw debugRunError;
    }

    await logWorkerAuditEvent(supabase, {
      organizationId: context.part.organization_id,
      jobId: task.job_id!,
      eventType: "worker.debug_extraction_completed",
      payload: {
        partId: context.part.id,
        debugRunId,
        requestedModel,
        effectiveModel,
        workerBuildVersion: config.workerBuildVersion,
        extractorVersion,
        extractionStatus: extraction.status,
        extractionLifecycle: extractionOutcome.lifecycle,
        warningCount: extraction.warnings.length,
        missingFields: extractionOutcome.missingFields,
        reviewFields: extractionOutcome.reviewFields,
      },
    });

    await markTaskCompleted(supabase, task, {
      debugRunId,
      requestedModel,
      effectiveModel,
      workerBuildVersion: config.workerBuildVersion,
      extractorVersion,
      extractionStatus: extraction.status,
      extractionLifecycle: extractionOutcome.lifecycle,
      warningCount: extraction.warnings.length,
      missingFields: extractionOutcome.missingFields,
      reviewFields: extractionOutcome.reviewFields,
    });
  } catch (error) {
    await supabase
      .from("debug_extraction_runs")
      .update({
        status: "failed",
        effective_model: requestedModel ?? config.drawingExtractionModel,
        worker_build_version: config.workerBuildVersion,
        error: summarizeWorkerError(error),
        completed_at: new Date().toISOString(),
      })
      .eq("id", debugRunId);

    throw error;
  } finally {
    await cleanupPaths(runDir ? [runDir] : []);
  }
}

/**
 * Runs vendor automation while moving the quote result through running and terminal states.
 * Retryable automation or persistence failures are rethrown for queue retry; terminal
 * failures are recorded on the result before the task completes.
 */
async function handleVendorQuoteTask(
  supabase: SupabaseClient,
  task: QueueTaskRecord,
  config: WorkerConfig,
) {
  if (!task.part_id || !task.quote_run_id || !task.job_id) {
    throw new Error("run_vendor_quote task is missing part_id, quote_run_id, or job_id.");
  }

  const vendor = task.payload.vendor as VendorName | undefined;
  const vendorQuoteResultId =
    typeof task.payload.vendorQuoteResultId === "string" ? task.payload.vendorQuoteResultId : null;
  const requestedQuantity =
    typeof task.payload.requestedQuantity === "number"
      ? task.payload.requestedQuantity
      : typeof task.payload.requestedQuantity === "string"
        ? Number.parseInt(task.payload.requestedQuantity, 10)
        : requestedQuantityFallback(task);

  if (!vendor) {
    throw new Error("run_vendor_quote task is missing vendor in payload.");
  }

  const requestStatusAtStart = await fetchQuoteRequestStatusForTask(supabase, task);

  if (requestStatusAtStart === "canceled") {
    await markTaskCancelled(supabase, task, "Canceled before vendor automation started.", {
      ignoredDueToCanceledRequest: true,
    });
    return;
  }

  const context = await fetchPartContext(supabase, task.part_id);

  if (!context.requirement) {
    throw new Error(`No approved requirement found for part ${task.part_id}.`);
  }
  const requirementCapturedAt = context.requirement.updated_at;
  if (!requirementCapturedAt) {
    throw new Error(
      `Approved requirement ${context.requirement.id} is missing its update timestamp.`,
    );
  }

  const currentResultRequest = vendorQuoteResultId
    ? supabase
        .from("vendor_quote_results")
        .select("id, requested_quantity")
        .eq("id", vendorQuoteResultId)
        .single()
    : supabase
        .from("vendor_quote_results")
        .select("id, requested_quantity")
        .eq("quote_run_id", task.quote_run_id)
        .eq("part_id", task.part_id)
        .eq("vendor", vendor)
        .eq("requested_quantity", Math.max(1, requestedQuantity))
        .single();

  const { data: currentResult, error: currentResultError } = await currentResultRequest;

  if (currentResultError || !currentResult) {
    throw currentResultError ?? new Error("Vendor quote result row was not found.");
  }

  const retryCount = retryCountForAttempts(task.attempts);

  await supabase
    .from("vendor_quote_results")
    .update({
      status: "running",
      notes:
        retryCount > 0
          ? [`Retry attempt ${retryCount + 1} is in progress.`]
          : ["Vendor automation is in progress."],
      raw_payload: {
        retryCount,
        failureCode: null,
        retryScheduledFor: null,
        requestedQuantity: currentResult.requested_quantity,
      },
    })
    .eq("id", currentResult.id);

  const adapters = buildAdapterRegistry(config);
  const adapter = adapters[vendor];
  const artifactDirs = new Set<string>();
  let stageDir: string | null = null;

  if (!adapter) {
    const manualReasonCode = "adapter_not_enabled";

    await supabase
      .from("vendor_quote_results")
      .update({
        status: "manual_vendor_followup",
        notes: [
          config.workerMode === "live"
            ? `${vendor} is disabled by WORKER_LIVE_ADAPTERS and requires manual vendor follow-up.`
            : `${vendor} is configured as a manual/import quote source in this environment.`,
        ],
        raw_payload: {
          mode: config.workerMode,
          source: "manual-import-vendor",
          requiresManualVendorFollowUp: true,
          manualFollowUpReason: manualReasonCode,
          requestedQuantity: currentResult.requested_quantity,
          retryCount,
          failureCode: manualReasonCode,
          configuredLiveAdapters: config.workerLiveAdapters,
        },
      })
      .eq("id", currentResult.id);

    await syncJobStatusAfterVendorUpdate(supabase, task.job_id, task.quote_run_id);
    await markTaskCompleted(supabase, task, {
      vendorStatus: "manual_vendor_followup",
      manualVendor: true,
      manualReasonCode,
    });
    return;
  }

  // Browser automation bills as container time, so a lane is reserved before it
  // starts. Unlike the extraction path there is no degraded mode to fall back
  // to, so a refusal requeues the lane rather than failing it: the work is still
  // wanted, just not at this moment's price.
  const vendorSpendGuard = createSpendGuard(supabase, task.organization_id);
  let vendorReservation;
  try {
    vendorReservation = await vendorSpendGuard.reserve("vendor_automation", VENDOR_RUN_SPEND_ESTIMATE_USD, {
      jobId: task.job_id,
      partId: task.part_id,
      quoteRunId: task.quote_run_id,
      taskId: task.id,
    });
  } catch (error) {
    if (error instanceof SpendCapExceededError) {
      const retryAt = nextRetryAt(task.attempts);

      // The result row was set to "running" before this point. Every other
      // terminal path here moves it on; without this it would sit reporting
      // "running" forever on a lane that was never going to run -- a
      // customer-facing quote that silently never resolves.
      await supabase
        .from("vendor_quote_results")
        .update({
          status: retryAt ? "queued" : "manual_vendor_followup",
          notes: [
            retryAt
              ? `Spend cap reached; this lane will retry. ${error.message}`
              : `Spend cap reached and retries are exhausted; this lane needs manual vendor follow-up. ${error.message}`,
          ],
          raw_payload: {
            mode: config.workerMode,
            requiresManualVendorFollowUp: !retryAt,
            manualFollowUpReason: "spend_cap_reached",
            spendCapReasonCode: error.reasonCode,
            requestedQuantity: currentResult.requested_quantity,
            failureCode: "spend_cap_reached",
          },
        })
        .eq("id", currentResult.id);

      if (retryAt) {
        await markTaskQueuedForRetry(supabase, task, `Spend cap reached: ${error.message}`, retryAt, {
          spendCapReasonCode: error.reasonCode,
        });
      } else {
        // Retries are exhausted, but nothing about this lane is broken -- it was
        // priced out. Cancelling rather than failing keeps the distinction, so it
        // reads as "not run" instead of "tried and defective" and can simply be
        // requested again once budget is available.
        await markTaskCancelled(supabase, task, `Spend cap reached: ${error.message}`, {
          spendCapReasonCode: error.reasonCode,
        });
      }
      return;
    }
    throw error;
  }

  // Only container time actually consumed should be charged. Staging can fail
  // before the browser ever launches, and settling the full estimate for a lane
  // that never started would hold budget for spend that did not happen.
  let vendorAutomationStarted = false;

  try {
    stageDir = await createRunDir(config, ["staging", task.quote_run_id, task.part_id]);
    const stagedCadFile = await stageStorageObject(supabase, context.cadFile, stageDir);
    const stagedDrawingFile = await stageStorageObject(supabase, context.drawingFile, stageDir);
    const scopeSnapshot = buildQuoteLaneScopeSnapshot({
      part: context.part,
      cadFile: context.cadFile,
      drawingFile: context.drawingFile,
      stagedCadFile,
      stagedDrawingFile,
      requirement: context.requirement,
      vendor,
      requestedQuantity: currentResult.requested_quantity,
    });
    const { error: laneRegistrationError } = await supabase.rpc(
      "api_register_quote_request_lane",
      {
        p_vendor_quote_result_id: currentResult.id,
        p_scope_snapshot: scopeSnapshot,
      },
    );
    if (laneRegistrationError) {
      throw laneRegistrationError;
    }
    const result = await quoteWithDispatchPreflight({
      supabase,
      config,
      workQueueTaskId: task.id,
      vendorQuoteResultId: currentResult.id,
      claimedAt: task.locked_at ?? "",
      vendor,
      scopeSnapshot,
      adapter,
      quoteInput: {
        organizationId: task.organization_id,
        quoteRunId: task.quote_run_id,
        part: context.part,
        cadFile: context.cadFile,
        drawingFile: context.drawingFile,
        stagedCadFile,
        stagedDrawingFile,
        requirement: context.requirement,
        requestedQuantity: currentResult.requested_quantity,
      },
      onAuthorized: () => {
        vendorAutomationStarted = true;
      },
    });

    result.artifacts.forEach((artifact: VendorArtifact) =>
      artifactDirs.add(path.dirname(artifact.localPath)),
    );
    const artifactStoragePaths = await persistVendorArtifacts(supabase, config, {
      vendorQuoteResultId: currentResult.id,
      organizationId: task.organization_id,
      quoteRunId: task.quote_run_id,
      partId: task.part_id,
      vendor,
      artifacts: result.artifacts,
    });

    const offerPayloads = buildVendorQuoteOfferPayloads({
      vendorQuoteResultId: currentResult.id,
      organizationId: task.organization_id,
      vendor,
      requestedQuantity: currentResult.requested_quantity,
      requirement: context.requirement,
      requirementCapturedAt,
      result,
    });

    await finalizeVendorQuoteResult(
      supabase,
      currentResult.id,
      {
        status: result.status,
        unit_price_usd: result.unitPriceUsd,
        total_price_usd: result.totalPriceUsd,
        lead_time_business_days: result.leadTimeBusinessDays,
        quote_url: result.quoteUrl,
        dfm_issues: result.dfmIssues,
        notes: result.notes,
        raw_payload: {
          ...result.rawPayload,
          offers: result.offers ?? [],
          artifactStoragePaths,
          requestedQuantity: currentResult.requested_quantity,
          requirementCapturedAt,
          retryCount,
          failureCode: null,
        },
      },
      offerPayloads,
    );

    // Compute and store routing scores for this quote run.
    // This is a best-effort operation — it will only succeed once all
    // vendor quotes for the run are in a terminal state.
    try {
      await computeAndStoreRoutingScores(
        supabase,
        task.quote_run_id,
        task.organization_id,
      );
    } catch (scoringError) {
      // Non-fatal: do not fail the task if scoring fails
      console.warn(
        JSON.stringify({
          service: "overdrafter-cad-worker",
          level: "warn",
          source: "worker.scoring",
          message: `Routing score computation failed: ${summarizeWorkerError(scoringError)}`,
          context: { quoteRunId: task.quote_run_id },
        }),
      );
    }

    const requestStatusAfterResult = await fetchQuoteRequestStatusForTask(supabase, task);

    if (requestStatusAfterResult === "canceled") {
      await markTaskCancelled(supabase, task, "Canceled while vendor automation was in flight.", {
          vendorStatus: result.status,
        artifactCount: artifactStoragePaths.length,
        ignoredDueToCanceledRequest: true,
      });
      return;
    }

    await syncJobStatusAfterVendorUpdate(supabase, task.job_id, task.quote_run_id);
    await markTaskCompleted(supabase, task, {
      vendorStatus: result.status,
      artifactCount: artifactStoragePaths.length,
    });
  } catch (error) {
    const vendorError =
      error instanceof VendorAutomationError ? error : null;
    const dispatchAuthorizationError =
      error instanceof XometryDispatchAuthorizationError ? error : null;
    const failureArtifacts = vendorError?.artifacts ?? [];
    failureArtifacts.forEach((artifact) => artifactDirs.add(path.dirname(artifact.localPath)));
    const failureArtifactStoragePaths =
      failureArtifacts.length > 0
        ? await persistVendorArtifacts(supabase, config, {
            vendorQuoteResultId: currentResult.id,
            organizationId: task.organization_id,
            quoteRunId: task.quote_run_id,
            partId: task.part_id,
            vendor,
            artifacts: failureArtifacts,
          })
        : [];

    if (vendorError) {
      await enqueueRepairCandidate(supabase, task, vendorError);
    }

    const failureCode = dispatchAuthorizationError
      ? dispatchAuthorizationError.reasonCode
      : failureCodeForError(error);
    const failureMessage = summarizeWorkerError(error);
    const retryableDispatchAuthorizationError =
      dispatchAuthorizationError?.reasonCode === "dispatch_preflight_unavailable";
    const requiresManualVendorFollowUp =
      vendorError?.code === "not_implemented" ||
      Boolean(dispatchAuthorizationError && !retryableDispatchAuthorizationError);
    const retryAt =
      requiresManualVendorFollowUp ||
      !(retryableDispatchAuthorizationError || isRetryableVendorTaskError(error))
        ? null
        : nextRetryAt(task.attempts);
    let manualReasonCode: string | null = null;
    if (dispatchAuthorizationError && !retryableDispatchAuthorizationError) {
      manualReasonCode = dispatchAuthorizationError.reasonCode;
    } else if (requiresManualVendorFollowUp) {
      manualReasonCode = "adapter_not_implemented";
    }
    let resultStatus: "queued" | "manual_vendor_followup" | "failed" = "failed";
    if (requiresManualVendorFollowUp) {
      resultStatus = "manual_vendor_followup";
    } else if (retryAt) {
      resultStatus = "queued";
    }
    let failureNote = failureMessage;
    if (retryableDispatchAuthorizationError && retryAt) {
      failureNote = `Xometry dispatch authorization is temporarily unavailable. Retry scheduled for ${retryAt}.`;
    } else if (dispatchAuthorizationError) {
      failureNote =
        "Automatic Xometry dispatch authorization was denied before browser launch; manual follow-up is required.";
    } else if (requiresManualVendorFollowUp) {
      failureNote = `${vendor} live automation is not implemented; manual vendor follow-up is required.`;
    } else if (retryAt) {
      failureNote = `Transient vendor automation failure. Retry scheduled for ${retryAt}. ${failureMessage}`;
    }

    await supabase
      .from("vendor_quote_results")
      .update({
        status: resultStatus,
        notes: [failureNote],
        raw_payload: {
          ...buildFailureRawPayload(
            vendor,
            retryCount,
            failureCode,
            vendorError?.payload ?? {},
            failureArtifactStoragePaths,
          ),
          requestedQuantity: currentResult.requested_quantity,
          retryScheduledFor: retryAt,
          requiresManualVendorFollowUp,
          manualFollowUpReason: manualReasonCode,
        },
      })
      .eq("id", currentResult.id);

    await syncJobStatusAfterVendorUpdate(supabase, task.job_id, task.quote_run_id);

    if (requiresManualVendorFollowUp) {
      await markTaskCompleted(supabase, task, {
          vendorStatus: "manual_vendor_followup",
        manualVendor: true,
        manualReasonCode,
        failureCode,
      });
      return;
    }

    throw error;
  } finally {
    // Settle regardless of outcome: an estimate left booked for a lane that
    // never ran would hold budget for the rest of the window.
    await vendorSpendGuard.settle(
      vendorReservation,
      vendorAutomationStarted ? VENDOR_RUN_SPEND_ESTIMATE_USD : 0,
    );
    await cleanupPaths([stageDir, ...artifactDirs]);
  }
}

async function fetchQuoteRequestStatusForTask(
  supabase: SupabaseClient,
  task: QueueTaskRecord,
): Promise<"queued" | "requesting" | "received" | "failed" | "canceled" | null> {
  const requestId =
    typeof task.payload.quoteRequestId === "string" ? task.payload.quoteRequestId : null;

  if (requestId) {
    const { data, error } = await supabase
      .from("quote_requests")
      .select("status")
      .eq("id", requestId)
      .maybeSingle();

    if (error) {
      throw error;
    }

    return (data?.status as "queued" | "requesting" | "received" | "failed" | "canceled" | null) ?? null;
  }

  if (!task.quote_run_id) {
    return null;
  }

  const { data, error } = await supabase
    .from("quote_runs")
    .select("quote_request_id, quote_requests(status)")
    .eq("id", task.quote_run_id)
    .maybeSingle();

  if (error) {
    throw error;
  }

  const quoteRequest = data && typeof data === "object" && "quote_requests" in data
    ? (data.quote_requests as { status?: string } | { status?: string }[] | null)
    : null;

  if (!quoteRequest || Array.isArray(quoteRequest)) {
    return null;
  }

  return (quoteRequest.status as "queued" | "requesting" | "received" | "failed" | "canceled" | null) ?? null;
}

function requestedQuantityFallback(task: QueueTaskRecord) {
  if (typeof task.payload.requestedQuantity === "number") {
    return task.payload.requestedQuantity;
  }

  if (typeof task.payload.requestedQuantity === "string") {
    const parsed = Number.parseInt(task.payload.requestedQuantity, 10);
    if (Number.isFinite(parsed)) {
      return parsed;
    }
  }

  return 1;
}

async function handlePublishTask(supabase: SupabaseClient, task: QueueTaskRecord) {
  const jobId = task.job_id ?? (task.payload.jobId as string | undefined);
  const quoteRunId = task.quote_run_id ?? (task.payload.quoteRunId as string | undefined);

  if (!jobId || !quoteRunId) {
    throw new Error("publish_package task is missing jobId or quoteRunId.");
  }

  const { error } = await supabase.rpc("api_publish_quote_package", {
    p_job_id: jobId,
    p_quote_run_id: quoteRunId,
    p_client_summary: (task.payload.clientSummary as string | undefined) ?? null,
    p_force: false,
  });

  if (error) {
    throw error;
  }

  await markTaskCompleted(supabase, task, {
    published: true,
  });
}

async function handleRepairTask(supabase: SupabaseClient, task: QueueTaskRecord) {
  const suggestion = suggestLocatorUpdate({
    failedSelector: String(task.payload.failedSelector ?? ""),
    errorMessage: String(task.payload.errorMessage ?? ""),
    nearbyAttributes: Array.isArray(task.payload.nearbyAttributes)
      ? (task.payload.nearbyAttributes as string[])
      : [],
  });

  await markTaskCompleted(supabase, task, {
    repairSuggestion: suggestion,
  });
}

async function processTask(
  supabase: SupabaseClient,
  task: QueueTaskRecord,
  config: WorkerConfig,
) {
  switch (task.task_type) {
    case "extract_part":
      await handleExtractTask(supabase, task, config);
      return;
    case "debug_extract_part":
      await handleDebugExtractTask(supabase, task, config);
      return;
    case "generate_cad_preview":
      await handleGenerateCadPreviewTask(supabase, task, config);
      return;
    case "run_vendor_quote":
      await handleVendorQuoteTask(supabase, task, config);
      return;
    case "publish_package":
      await handlePublishTask(supabase, task);
      return;
    case "repair_adapter_candidate":
      await handleRepairTask(supabase, task);
      return;
    case "poll_vendor_quote":
      await markTaskCompleted(supabase, task, {
          pollSkipped: true,
      });
      return;
    default:
      throw new Error(`Unhandled task type: ${task.task_type}`);
  }
}

async function main() {
  const baseConfig = loadConfig();
  const runtimeState = createWorkerRuntimeState();
  let config = baseConfig;
  let startupReadinessIssue: string | null = null;

  try {
    config = await prepareRuntimeSecrets(baseConfig);
  } catch (error) {
    startupReadinessIssue = summarizeWorkerError(error);
  }

  const supabase = createServiceClient(config);
  const modelCatalogManager = new ExtractionModelCatalogManager(config);
  const healthServer = await startHealthServer(config, runtimeState, {
    getExtractionModels: async () => modelCatalogManager.getCatalog(),
    refreshExtractionModels: async () => ({
      accepted: true,
      catalog: await modelCatalogManager.refreshNow(),
    }),
    previewExtraction: async ({ partId, modelId }) =>
      previewStoredPartExtraction(config, { partId, modelId }),
  });
  let stopping = false;

  const logReadinessChange = (issues: string[]) => {
    if (issues.length > 0) {
      logWorkerEvent(runtimeState, {
        level: "error",
        source: "worker.readiness",
        message: "Worker is not ready to process tasks.",
        context: {
          issues,
        },
      });
      return;
    }

    logWorkerEvent(runtimeState, {
      level: "info",
      source: "worker.readiness",
      message: "Worker readiness checks passed.",
    });
  };

  const requestShutdown = (signal: string) => {
    if (stopping) {
      return;
    }

    stopping = true;
    runtimeState.status = "shutting_down";
    logWorkerEvent(runtimeState, {
      level: "info",
      source: "worker.shutdown",
      message: `Received ${signal}; shutting down after the current cycle.`,
      context: {
        signal,
      },
    });
  };

  process.on("SIGTERM", () => requestShutdown("SIGTERM"));
  process.on("SIGINT", () => requestShutdown("SIGINT"));
  process.on("unhandledRejection", (error) => {
    const message = error instanceof Error ? error.message : String(error);
    runtimeState.lastError = message;
    logWorkerEvent(runtimeState, {
      level: "error",
      source: "process.unhandledRejection",
      message,
      error,
    });
  });
  process.on("uncaughtExceptionMonitor", (error) => {
    runtimeState.lastError = error.message;
    logWorkerEvent(runtimeState, {
      level: "error",
      source: "process.uncaughtException",
      message: error.message,
      error,
    });
  });

  logWorkerEvent(runtimeState, {
    level: "info",
    source: "worker.startup",
    message:
      config.workerMode === "live"
        ? "Starting worker in live mode."
        : `Starting worker ${config.workerName} in ${config.workerMode} mode.`,
    context: {
      workerName: config.workerName,
      workerMode: config.workerMode,
      healthUrl: healthServer.url,
      pollIntervalMs: config.pollIntervalMs,
      quantityPricingLadder: config.quantityPricingLadder,
      vendorRateLimitMs: config.vendorRateLimitMs,
      drawingExtractionModelFallback: config.drawingExtractionEnableModelFallback,
      drawingExtractionModel: config.drawingExtractionModel,
    },
  });

  const xometrySessionAgeDays = await getXometrySessionAgeDays(config);
  if (
    xometrySessionAgeDays !== null &&
    xometrySessionAgeDays > config.xometrySessionFreshnessWarnDays
  ) {
    const ageDaysRounded = Math.floor(xometrySessionAgeDays);
    logWorkerEvent(runtimeState, {
      level: "warn",
      source: "worker.session_freshness",
      message: `Xometry session is ${ageDaysRounded} days old — consider re-authenticating.`,
      context: {
        xometrySessionAgeDays,
        thresholdDays: config.xometrySessionFreshnessWarnDays,
      },
    });
  }

  if (shouldWarnSimulateModeInProduction(config)) {
    logWorkerEvent(runtimeState, {
      level: "warn",
      source: "worker.configuration",
      message:
        "WORKER_MODE=simulate detected in production-like environment; vendor quotes will not run live automation.",
      context: {
        workerMode: config.workerMode,
        nodeEnv: process.env.NODE_ENV ?? null,
        vercelEnv: process.env.VERCEL_ENV ?? null,
        appEnv: process.env.APP_ENV ?? null,
      },
    });
  }

  runtimeState.status = "running";

  if (startupReadinessIssue) {
    runtimeState.readinessIssues = [startupReadinessIssue];
    runtimeState.lastError = startupReadinessIssue;
    logReadinessChange(runtimeState.readinessIssues);
  } else {
    await refreshRuntimeReadiness(config, runtimeState, logReadinessChange);
  }

  // Reap stale tasks once at startup, then every 60 seconds.
  let lastReapAt = 0;
  const REAP_INTERVAL_MS = 60_000;

  while (!stopping) {
    runtimeState.lastLoopAt = new Date().toISOString();
    const ready = startupReadinessIssue
      ? false
      : await refreshRuntimeReadiness(config, runtimeState, logReadinessChange);

    if (!ready) {
      await sleep(config.pollIntervalMs);
      continue;
    }

    const now = Date.now();
    if (now - lastReapAt >= REAP_INTERVAL_MS) {
      lastReapAt = now;
      try {
        const reaped = await reapStaleTasks(supabase);
        if (reaped > 0) {
          logWorkerEvent(runtimeState, {
            level: "warn",
            source: "worker.reaper",
            message: `Reaped ${reaped} stale task(s) stuck in running state.`,
            context: { reaped },
          });
        }
      } catch (reaperError) {
        logWorkerEvent(runtimeState, {
          level: "error",
          source: "worker.reaper",
          message: `Dead-task reaper failed: ${summarizeWorkerError(reaperError)}`,
          error: reaperError,
        });
      }
    }

    const task = await claimNextTask(supabase, config.workerName);

    if (!task) {
      await sleep(config.pollIntervalMs);
      continue;
    }

    const taskSummary = {
      id: task.id,
      type: task.task_type,
    };
    runtimeState.currentTask = taskSummary;
    runtimeState.lastTaskStartedAt = new Date().toISOString();
    const taskStartMs = Date.now();
    logWorkerEvent(runtimeState, {
      level: "info",
      source: "worker.task.start",
      message: `Starting ${task.task_type} ${task.id}.`,
      context: buildTaskContext(task),
    });

    try {
      await processTask(supabase, task, config);
      runtimeState.lastTaskCompletedAt = new Date().toISOString();
      runtimeState.lastCompletedTask = taskSummary;
      runtimeState.lastError = null;
      logWorkerEvent(runtimeState, {
        level: "info",
        source: "worker.task.complete",
        message: `Completed ${task.task_type} ${task.id}.`,
        context: {
          ...buildTaskContext(task),
          task_duration_ms: Date.now() - taskStartMs,
        },
      });
    } catch (error) {
      let retryAt: string | null = null;
      const shouldRetry =
        (task.task_type === "generate_cad_preview" && isRetryableCadPreviewError(error)) ||
        (task.task_type === "extract_part" && error instanceof CanonicalArtifactsPendingError) ||
        (task.task_type === "run_vendor_quote" && isRetryableVendorTaskError(error));
      if (shouldRetry) {
        retryAt = nextRetryAt(task.attempts);
      }
      const retryCount = retryCountForAttempts(task.attempts);
      const failureEvidence = buildWorkerTaskFailureEvidence(
        error,
        failureCodeForError(error),
        retryCount,
      );
      const message = failureEvidence.failureMessage;

      if (retryAt) {
        await markTaskQueuedForRetry(supabase, task, failureEvidence.failureMessage, retryAt, {
          ...failureEvidence.payload,
          nextRetryAt: retryAt,
        });
      } else {
        await markTaskFailed(
          supabase,
          task,
          failureEvidence.failureMessage,
          failureEvidence.payload,
        );
      }

      runtimeState.lastTaskFailedAt = new Date().toISOString();
      runtimeState.lastFailedTask = taskSummary;
      runtimeState.lastError = message;
      logWorkerEvent(runtimeState, {
        level: retryAt ? "warn" : "error",
        source: retryAt ? "worker.task.retry" : "worker.task.failure",
        message: retryAt
          ? `Retrying ${task.task_type} ${task.id} at ${retryAt}: ${message}`
          : `Failed ${task.task_type} ${task.id}: ${message}`,
        context: {
          ...buildTaskContext(task),
          task_duration_ms: Date.now() - taskStartMs,
          retryCount,
          nextRetryAt: retryAt,
        },
        error: failureEvidence.runtimeError,
      });
    } finally {
      runtimeState.currentTask = null;
    }

    if (!stopping && task.task_type === "run_vendor_quote" && config.vendorRateLimitMs > 0) {
      await sleep(config.vendorRateLimitMs);
    }
  }

  await healthServer.close();
}

main().catch((error) => {
  console.error(
    JSON.stringify({
      service: "overdrafter-cad-worker",
      level: "error",
      source: "worker.startup.fatal",
      message: error instanceof Error ? error.message : String(error),
      error:
        error instanceof Error
          ? {
              name: error.name,
              message: error.message,
              stack: error.stack ?? null,
            }
          : null,
    }),
  );
  process.exit(1);
});
