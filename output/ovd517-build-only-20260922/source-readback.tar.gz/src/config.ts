import { z } from "zod";
import path from "node:path";
import os from "node:os";
import { parseEnvBooleanLike, parseEnvList } from "./env.js";
import { DEFAULT_QUANTITY_PRICING_LADDER, normalizePricingLadder } from "./quantityPricing.js";
import { hasDirectExtractionCredential } from "./extraction/modelRegistry.js";
import { LIVE_AUTOMATION_VENDORS, type LiveAutomationVendorName, type WorkerConfig } from "./types.js";

const envBoolean = z.preprocess((value) => {
  if (typeof value === "boolean") {
    return value;
  }

  if (typeof value !== "string") {
    return value;
  }

  const normalized = value.trim().toLowerCase();

  if (["1", "true", "yes", "on"].includes(normalized)) {
    return true;
  }

  if (["0", "false", "no", "off", ""].includes(normalized)) {
    return false;
  }

  return value;
}, z.boolean());

/**
 * An optional setting that treats a declared-but-empty variable as absent.
 *
 * CI and container runtimes routinely export a variable as `""` when the
 * underlying secret is unset — GitHub Actions does this for every
 * `${{ secrets.X }}` reference. A plain `.optional()` sees that empty string as
 * *present* and fails validation, so a worker with no optional credentials
 * configured cannot start at all. Empty and whitespace-only both read as unset.
 */
function optionalSetting(inner: z.ZodTypeAny = z.string().min(1)) {
  return z.preprocess(
    (value) => (typeof value === "string" && value.trim() === "" ? undefined : value),
    inner.optional(),
  );
}

const schema = z.object({
  SUPABASE_URL: z.string().url(),
  SUPABASE_SERVICE_ROLE_KEY: z.string().min(1),
  WORKER_MODE: z.enum(["simulate", "live"]).default("simulate"),
  WORKER_LIVE_ADAPTERS: z.string().optional(),
  QUOTE_VENDOR_STORAGE_STATE_DIR: optionalSetting(),
  QUOTE_VENDOR_STORAGE_STATE_PATHS: optionalSetting(),
  QUOTE_VENDOR_STORAGE_STATE_JSON: optionalSetting(),
  WORKER_NAME: z.string().default("quote-worker-1"),
  WORKER_POLL_INTERVAL_MS: z.coerce.number().int().positive().default(5000),
  WORKER_QUANTITY_PRICING_LADDER: z.string().default(DEFAULT_QUANTITY_PRICING_LADDER.join(",")),
  WORKER_VENDOR_RATE_LIMIT_MS: z.coerce.number().int().nonnegative().default(0),
  WORKER_PRICING_MODEL_ENABLED: envBoolean.default(false),
  WORKER_PRICING_MODEL_MIN_CONFIDENCE: z.coerce.number().min(0).max(1).default(0.7),
  WORKER_HTTP_HOST: z.string().default("0.0.0.0"),
  WORKER_TEMP_DIR: z.string().default(path.join(os.tmpdir(), "overdrafter-worker")),
  QUOTE_ARTIFACT_BUCKET: z.string().default("quote-artifacts"),
  PORT: z.coerce.number().int().positive().default(8080),
  PLAYWRIGHT_HEADLESS: envBoolean.default(true),
  PLAYWRIGHT_CAPTURE_TRACE: envBoolean.default(false),
  PLAYWRIGHT_BROWSER_TIMEOUT_MS: z.coerce.number().int().positive().default(30000),
  PLAYWRIGHT_DISABLE_SANDBOX: envBoolean.default(false),
  PLAYWRIGHT_DISABLE_DEV_SHM_USAGE: envBoolean.default(true),
  XOMETRY_STORAGE_STATE_PATH: optionalSetting(),
  XOMETRY_STORAGE_STATE_JSON: optionalSetting(),
  XOMETRY_USER_DATA_DIR: optionalSetting(),
  XOMETRY_PROFILE_SNAPSHOT_BUCKET: optionalSetting(),
  XOMETRY_PROFILE_SNAPSHOT_OBJECT: optionalSetting(),
  XOMETRY_PROFILE_SNAPSHOT_MAX_BYTES: z.coerce.number().int().positive().default(268435456),
  XOMETRY_BROWSER_CHANNEL: optionalSetting(),
  XOMETRY_BROWSER_ENGINE: z.enum(["patchright", "playwright", "camoufox"]).default("playwright"),
  XOMETRY_PROFILE_LOCK_WAIT_MS: z.coerce.number().int().nonnegative().default(30000),
  XOMETRY_SESSION_FRESHNESS_WARN_DAYS: z.coerce.number().nonnegative().default(7),
  FICTIV_STORAGE_STATE_PATH: optionalSetting(),
  FICTIV_STORAGE_STATE_JSON: optionalSetting(),
  OPENAI_API_KEY: optionalSetting(),
  ANTHROPIC_API_KEY: optionalSetting(),
  OPENROUTER_API_KEY: optionalSetting(),
  WORKER_BUILD_VERSION: z.string().default("dev-local"),
  DRAWING_EXTRACTION_MODEL: z.string().default("gpt-5.4"),
  DRAWING_EXTRACTION_DEBUG_ALLOWED_MODELS: optionalSetting(),
  DRAWING_EXTRACTION_ENABLE_MODEL_FALLBACK: envBoolean.optional(),
});

function parseWorkerLiveAdapters(rawValue: string | undefined): LiveAutomationVendorName[] {
  const configuredAdapters =
    rawValue === undefined
      ? ["xometry"]
      : [
          ...new Set(
            rawValue
              .split(",")
              .map((entry) => entry.trim().toLowerCase())
              .filter(Boolean),
          ),
        ];

  const liveAutomationSet = new Set<string>(LIVE_AUTOMATION_VENDORS);
  const unsupportedAdapters = configuredAdapters.filter((entry) => !liveAutomationSet.has(entry));

  if (unsupportedAdapters.length > 0) {
    throw new Error(
      `WORKER_LIVE_ADAPTERS includes unsupported adapters: ${unsupportedAdapters.join(", ")}. Supported values: ${LIVE_AUTOMATION_VENDORS.join(", ")}.`,
    );
  }

  return configuredAdapters as LiveAutomationVendorName[];
}

function parseVendorStringRecord(rawValue: string | undefined, fieldName: string): Partial<Record<LiveAutomationVendorName, string>> {
  if (!rawValue || rawValue.trim().length === 0) {
    return {};
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(rawValue);
  } catch {
    throw new Error(`${fieldName} must be a JSON object keyed by vendor name.`);
  }

  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
    throw new Error(`${fieldName} must be a JSON object keyed by vendor name.`);
  }

  const liveAutomationSet = new Set<string>(LIVE_AUTOMATION_VENDORS);
  const result: Partial<Record<LiveAutomationVendorName, string>> = {};

  for (const [rawVendor, rawEntry] of Object.entries(parsed)) {
    const vendor = rawVendor.trim().toLowerCase();
    if (!liveAutomationSet.has(vendor)) {
      throw new Error(
        `${fieldName} includes unsupported vendor "${rawVendor}". Supported values: ${LIVE_AUTOMATION_VENDORS.join(", ")}.`,
      );
    }

    if (typeof rawEntry !== "string" || rawEntry.trim().length === 0) {
      throw new Error(`${fieldName}.${rawVendor} must be a non-empty string.`);
    }

    result[vendor as LiveAutomationVendorName] =
      fieldName === "QUOTE_VENDOR_STORAGE_STATE_PATHS" ? path.resolve(rawEntry) : rawEntry;
  }

  return result;
}

function parseQuantityPricingLadder(rawValue: string): number[] {
  const ladder = normalizePricingLadder(rawValue);

  if (ladder.length === 0) {
    throw new Error("WORKER_QUANTITY_PRICING_LADDER must include at least one positive integer quantity.");
  }

  return ladder;
}

export function loadConfig(env: NodeJS.ProcessEnv = process.env): WorkerConfig {
  const parsed = schema.parse(env);
  const workerTempDir = path.resolve(parsed.WORKER_TEMP_DIR);
  const workerLiveAdapters = parseWorkerLiveAdapters(parsed.WORKER_LIVE_ADAPTERS);
  const vendorStorageStateDir = parsed.QUOTE_VENDOR_STORAGE_STATE_DIR
    ? path.resolve(parsed.QUOTE_VENDOR_STORAGE_STATE_DIR)
    : null;
  const vendorStorageStatePaths = parseVendorStringRecord(
    parsed.QUOTE_VENDOR_STORAGE_STATE_PATHS,
    "QUOTE_VENDOR_STORAGE_STATE_PATHS",
  );
  const vendorStorageStateJson = parseVendorStringRecord(
    parsed.QUOTE_VENDOR_STORAGE_STATE_JSON,
    "QUOTE_VENDOR_STORAGE_STATE_JSON",
  );
  // Anthropic counts here too: it is a production extraction provider, not
  // only a debug-lab one, so a deployment holding just an Anthropic key still
  // has model fallback available.
  const hasDrawingExtractionModelKey = hasDirectExtractionCredential(
    parsed.DRAWING_EXTRACTION_MODEL,
    {
      openai: parsed.OPENAI_API_KEY,
      anthropic: parsed.ANTHROPIC_API_KEY,
    },
  );
  const drawingExtractionDebugAllowedModels = parseEnvList(
    parsed.DRAWING_EXTRACTION_DEBUG_ALLOWED_MODELS,
    parsed.DRAWING_EXTRACTION_MODEL,
  );
  const quantityPricingLadder = parseQuantityPricingLadder(parsed.WORKER_QUANTITY_PRICING_LADDER);
  const snapshotBucket = parsed.XOMETRY_PROFILE_SNAPSHOT_BUCKET ?? null;
  const snapshotObject = parsed.XOMETRY_PROFILE_SNAPSHOT_OBJECT ?? null;

  if (Boolean(snapshotBucket) !== Boolean(snapshotObject)) {
    throw new Error(
      "XOMETRY_PROFILE_SNAPSHOT_BUCKET and XOMETRY_PROFILE_SNAPSHOT_OBJECT must be configured together.",
    );
  }

  if (snapshotBucket && (parsed.XOMETRY_STORAGE_STATE_PATH || parsed.XOMETRY_STORAGE_STATE_JSON)) {
    throw new Error(
      "Xometry profile snapshot mode cannot be combined with storage-state credentials.",
    );
  }

  if (snapshotBucket && parsed.XOMETRY_USER_DATA_DIR) {
    throw new Error(
      "XOMETRY_USER_DATA_DIR is managed locally by profile snapshot mode and must not also be configured.",
    );
  }

  let xometryUserDataDir: string | null = null;
  if (parsed.XOMETRY_USER_DATA_DIR) {
    xometryUserDataDir = path.resolve(parsed.XOMETRY_USER_DATA_DIR);
  } else if (snapshotBucket) {
    xometryUserDataDir = path.join(workerTempDir, "xometry-profile");
  }

  return {
    supabaseUrl: parsed.SUPABASE_URL,
    supabaseServiceRoleKey: parsed.SUPABASE_SERVICE_ROLE_KEY,
    workerMode: parsed.WORKER_MODE,
    workerLiveAdapters,
    vendorStorageStateDir,
    vendorStorageStatePaths,
    vendorStorageStateJson,
    workerName: parsed.WORKER_NAME,
    pollIntervalMs: parsed.WORKER_POLL_INTERVAL_MS,
    quantityPricingLadder,
    vendorRateLimitMs: parsed.WORKER_VENDOR_RATE_LIMIT_MS,
    pricingModelEnabled: parsed.WORKER_PRICING_MODEL_ENABLED,
    pricingModelMinConfidence: parsed.WORKER_PRICING_MODEL_MIN_CONFIDENCE,
    httpHost: parsed.WORKER_HTTP_HOST,
    httpPort: parsed.PORT,
    workerTempDir,
    artifactBucket: parsed.QUOTE_ARTIFACT_BUCKET,
    playwrightHeadless: parsed.PLAYWRIGHT_HEADLESS,
    playwrightCaptureTrace: parsed.PLAYWRIGHT_CAPTURE_TRACE,
    browserTimeoutMs: parsed.PLAYWRIGHT_BROWSER_TIMEOUT_MS,
    playwrightDisableSandbox: parsed.PLAYWRIGHT_DISABLE_SANDBOX,
    playwrightDisableDevShmUsage: parsed.PLAYWRIGHT_DISABLE_DEV_SHM_USAGE,
    xometryStorageStatePath: parsed.XOMETRY_STORAGE_STATE_PATH
      ? path.resolve(parsed.XOMETRY_STORAGE_STATE_PATH)
      : null,
    xometryStorageStateJson: parsed.XOMETRY_STORAGE_STATE_JSON ?? null,
    xometryUserDataDir,
    xometryProfileSnapshotBucket: snapshotBucket,
    xometryProfileSnapshotObject: snapshotObject,
    xometryProfileSnapshotGeneration: null,
    xometryProfileSnapshotMaxBytes: parsed.XOMETRY_PROFILE_SNAPSHOT_MAX_BYTES,
    xometryBrowserChannel: parsed.XOMETRY_BROWSER_CHANNEL ?? null,
    xometryBrowserEngine: parsed.XOMETRY_BROWSER_ENGINE,
    xometryProfileLockWaitMs: parsed.XOMETRY_PROFILE_LOCK_WAIT_MS,
    xometrySessionFreshnessWarnDays: parsed.XOMETRY_SESSION_FRESHNESS_WARN_DAYS,
    fictivStorageStatePath: parsed.FICTIV_STORAGE_STATE_PATH
      ? path.resolve(parsed.FICTIV_STORAGE_STATE_PATH)
      : null,
    fictivStorageStateJson: parsed.FICTIV_STORAGE_STATE_JSON ?? null,
    openAiApiKey: parsed.OPENAI_API_KEY ?? null,
    anthropicApiKey: parsed.ANTHROPIC_API_KEY ?? null,
    openRouterApiKey: parsed.OPENROUTER_API_KEY ?? null,
    workerBuildVersion: parsed.WORKER_BUILD_VERSION,
    drawingExtractionModel: parsed.DRAWING_EXTRACTION_MODEL,
    drawingExtractionEnableModelFallback: parseEnvBooleanLike(
      parsed.DRAWING_EXTRACTION_ENABLE_MODEL_FALLBACK,
      hasDrawingExtractionModelKey,
    ),
    drawingExtractionDebugAllowedModels,
  };
}
