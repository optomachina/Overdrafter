import { assertCamoufoxAssetsPresent } from "./camoufoxAssets.js";
import { launchOptions as camoufoxLaunchOptions } from "camoufox-js";
import { VirtualDisplay } from "camoufox-js/dist/virtdisplay.js";
import { firefox, type BrowserContext } from "playwright";
import {
  runFailClosedBrowserCleanup,
  type FailClosedBrowserCleanupOptions,
} from "./browserCleanup.js";

const CONFIG_PREFIX = "CAMOU_CONFIG_";
const CONFIG_CHUNK_BYTES = 32_767;

function readGeneratedConfig(
  options: Record<string, unknown>,
): Record<string, unknown> {
  const env = (options.env ?? {}) as Record<string, string>;
  const encoded = Object.entries(env)
    .filter(([key]) => key.startsWith(CONFIG_PREFIX))
    .sort(
      ([left], [right]) =>
        Number(left.slice(CONFIG_PREFIX.length)) -
        Number(right.slice(CONFIG_PREFIX.length)),
    )
    .map(([, value]) => value)
    .join("");
  const parsed = JSON.parse(encoded) as unknown;
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
    throw new Error("Camoufox did not produce a valid launch identity.");
  }
  return parsed as Record<string, unknown>;
}

function pinGeneratedConfig(
  options: Record<string, unknown>,
  config: Record<string, unknown>,
) {
  const env = { ...((options.env ?? {}) as Record<string, string>) };
  for (const key of Object.keys(env)) {
    if (key.startsWith(CONFIG_PREFIX)) delete env[key];
  }
  const encoded = JSON.stringify(config);
  for (
    let offset = 0, index = 1;
    offset < encoded.length;
    offset += CONFIG_CHUNK_BYTES, index += 1
  ) {
    env[`${CONFIG_PREFIX}${index}`] = encoded.slice(
      offset,
      offset + CONFIG_CHUNK_BYTES,
    );
  }
  return { ...options, env };
}

/**
 * Launches a persistent Camoufox context with one exact fingerprint.
 * Headless Linux owns a temporary virtual display while every platform forces
 * a headed browser launch; closing the returned context also owns display
 * cleanup, including launch and close failures.
 */
export async function launchPersistentCamoufox(input: {
  userDataDir: string;
  headless: boolean;
  identityConfig?: Record<string, unknown>;
  launchOverrides?: Record<string, unknown>;
}) {
  assertCamoufoxAssetsPresent();
  const virtualDisplay =
    input.headless && process.platform === "linux"
      ? new VirtualDisplay(false)
      : null;
  try {
    const generatedOptions = await camoufoxLaunchOptions({
      // The library mutates config while generating defaults; keep saved identity exact.
      config: structuredClone(input.identityConfig ?? {}),
      headless: false,
      window: [1366, 900],
      humanize: true,
      ...(virtualDisplay ? { virtual_display: virtualDisplay.get() } : {}),
      ...input.launchOverrides,
      geoip: false,
    });
    const identityConfig =
      input.identityConfig ?? readGeneratedConfig(generatedOptions);
    const context = (await firefox.launchPersistentContext(
      input.userDataDir,
      pinGeneratedConfig(generatedOptions, identityConfig),
    )) as BrowserContext;
    const originalClose = context.close.bind(context);
    context.close = async (...args) => {
      try {
        await originalClose(...args);
      } finally {
        virtualDisplay?.kill();
      }
    };
    return { context, identityConfig };
  } catch (error) {
    virtualDisplay?.kill();
    throw error;
  }
}

/** Always close a launched persistent context, including setup and navigation failures. */
export async function withPersistentCamoufoxContext<T>(
  input: Parameters<typeof launchPersistentCamoufox>[0],
  operation: (
    launched: Awaited<ReturnType<typeof launchPersistentCamoufox>>,
  ) => Promise<T>,
  cleanupOptions: FailClosedBrowserCleanupOptions = {},
): Promise<T> {
  const launched = await launchPersistentCamoufox(input);
  let primaryError: unknown;
  let result: T | undefined;
  try {
    result = await operation(launched);
  } catch (error) {
    primaryError = error;
  }

  try {
    await runFailClosedBrowserCleanup(
      () => launched.context.close(),
      "Camoufox context cleanup timed out; terminating task.",
      cleanupOptions,
    );
  } catch {
    const cleanupError = new Error("Camoufox context cleanup failed.");
    if (primaryError !== undefined) {
      const primaryMessage =
        primaryError instanceof Error
          ? primaryError.message
          : "Camoufox operation failed.";
      throw new AggregateError(
        [primaryError, cleanupError],
        `${primaryMessage} Browser cleanup also failed closed.`,
        { cause: primaryError },
      );
    }
    throw cleanupError;
  }
  if (primaryError !== undefined) throw primaryError;
  return result as T;
}
